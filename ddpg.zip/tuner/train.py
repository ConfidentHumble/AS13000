import os
import sys
import pickle
import argparse
sys.path.append('./')
print(sys.path)
import models
import matplotlib.pyplot as plt
import gym
import torch
import numpy as np

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--env_name", default="Pendulum-v0")
    parser.add_argument("--seed", default=0, type=int, help='Sets Gym, PyTorch and Numpy seeds')
    parser.add_argument('--params', type=str, default='', help='Load existing parameters')
    # parser.add_argument('--workload', type=str, default='read', help='Workload type [`read`, `write`, `readwrite`]')
    # parser.add_argument('--instance', type=str, default='mysql1', help='Choose MySQL Instance')
    parser.add_argument('--method', type=str, default='ddpg', help='Choose Algorithm to solve [`ddpg`,`dqn`]')
    parser.add_argument("--max_timesteps", default=1e5, type=float, help='max_timesteps')
    # parser.add_argument('--memory', type=str, default='', help='add replay memory')
    parser.add_argument('--noisy', action='store_true', help='use noisy linear layer')
    # parser.add_argument('--other_knob', type=int, default=0, help='Number of other knobs')
    parser.add_argument('--batch_size', type=int, default=100, help='Training Batch Size')
    parser.add_argument('--epoches', type=int, default=5000000, help='Training Epoches')
    # parser.add_argument('--benchmark', type=str, default='sysbench', help='[sysbench, tpcc]')
    # parser.add_argument('--metric_num', type=int, default=63, help='metric nums')
    # parser.add_argument('--default_knobs', type=int, default=6, help='default knobs')
    parser.add_argument("--expl_noise", default=0.1, type=float, help='Gaussian exploration')
    parser.add_argument("--start_timesteps", default=1e4, type=int, help='how many step random policy run')
    opt = parser.parse_args()

    env = gym.make(opt.env_name)
    env.seed(opt.seed)
    torch.manual_seed(opt.seed)
    np.random.seed(opt.seed)

    ddpg_opt = dict()
    ddpg_opt['tau'] = 0.00001
    ddpg_opt['alr'] = 0.00001
    ddpg_opt['clr'] = 0.00001
    ddpg_opt['model'] = opt.params
    # n_states = opt.metric_num
    gamma = 0.9
    memory_size = 100000
    # num_actions = opt.default_knobs + opt.other_knob
    ddpg_opt['gamma'] = gamma
    ddpg_opt['batch_size'] = opt.batch_size
    ddpg_opt['memory_size'] = memory_size

    model = models.DDPG(
        n_states=env.observation_space.shape[0],
        n_actions=env.action_space.shape[0],
        opt=ddpg_opt,
        mean_var_path='mean_var.pkl',
        ouprocess=not opt.noisy
    )

    total_timesteps = 0
    timesteps_since_eval = 0
    episode_num = 0
    episode_reward = 0
    episode_timesteps = 0
    done = True
    
    x_totalStep = []
    y_reward = []

    while total_timesteps < opt.max_timesteps:
        if done:
            if total_timesteps != 0:
                print(("Total T: %d Episode Num: %d Episode T: %d Reward: %f") % (total_timesteps, episode_num, episode_timesteps, episode_reward))
                # policy.train(replay_buffer, episode_timesteps, args.batch_size, args.GAMMA, args.tau)
                x_totalStep.append(total_timesteps)
                y_reward.append(episode_reward)

            obs = env.reset()
            done = False
            episode_reward = 0
            episode_timesteps = 0
            episode_num += 1

        if total_timesteps < opt.start_timesteps:
            action = env.action_space.sample()
        else:
            action = model.choose_action(np.array(obs))
            if opt.expl_noise != 0:
                action = (action + np.random.normal(0, opt.expl_noise, size=env.action_space.shape[0])).clip(
                    env.action_space.low, env.action_space.high)

        new_obs, reward, done, _ = env.step(action)
        done_bool = 0 if episode_timesteps + 1 == env._max_episode_steps else float(done)
        episode_reward += reward

        model.add_sample(obs, action, reward, new_obs, done_bool)        
        obs = new_obs
        episode_timesteps += 1
        total_timesteps += 1
        timesteps_since_eval += 1
    plt.plot(x_totalStep, y_reward)
    plt.show()    